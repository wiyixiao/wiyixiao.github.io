#include "HBR740.h"

HBR740::HBR740()
{
    unsigned char _Buf0[3] = {0xA0, 0xA0, 0xA0};
    for (int i = 0; i < 3; ++i)
    {
        _initializerBuf[i] = _Buf0[i];
    }

    unsigned char _Buf1[3] = {0xAB, 0xAB, 0x00};
    for (int i = 0; i < 3; ++i)
    {
        _openBuf[i] = _Buf1[i];
    }

    unsigned char _Buf2[3] = {0xAC, 0xAC, 0x00};
    for (int i = 0; i < 3; ++i)
    {
        _endBuf[i] = _Buf2[i];
    }

    _value = 0;
    _flag = 0; 
}

HBR740::~HBR740()
{
    ;
}

void HBR740::open()
{
    delay(2000);
    Serial.end();
    Serial.begin(115200);
    Serial.write(_initializerBuf, 3);
    delay(500);
    Serial.write(_openBuf, 3);
    delay(500);
}

void HBR740::lisen()
{
    if (Serial.available())
    {
        Serial.readBytes(_receiveBuf, 3);
        Serial.flush();
        _flag = 1;
    }
}

int HBR740::isHeard()
{
    return _flag;
}

int HBR740::getSentence()
{
    _flag = 0;
    return (int)((_receiveBuf[2] << 8) | (_receiveBuf[1]));
}

void HBR740::close()
{
    Serial.write(_endBuf, 3);
}

