#ifndef _HBR740_H
#define _HBR740_H

#include "HardwareSerial.h"
#include "Arduino.h"

class HBR740
{
public:
    HBR740();
    ~HBR740();
    void open();
    void lisen();
    int isHeard();
    int  getSentence();
    void close();

private:
    unsigned char _initializerBuf[3];
    unsigned char _openBuf[3];
    unsigned char _endBuf[3];
    char _receiveBuf[3];
    int  _value;
    int _flag;
};
#endif // _HBR740_H
